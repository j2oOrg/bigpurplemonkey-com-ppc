import"../react-vendor-0bea0611.js";import"./react-query-cb8e8166.js";const r=function(){return null};export{r as R};
